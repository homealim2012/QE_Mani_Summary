		DUC 2005 Summarization Documents


Created: March 1, 2011


1. Overview

This package contains test documents from the DUC 2005 summarization
task.  Also included are additional annotations of the test documents
that were contributed by participants after the official evaluation.

Additional DUC 2005 data are available at:
   http://duc.nist.gov/data.html

DUC 2005 task guidelines are available at:
   http://duc.nist.gov/guidelines/2005.html


2. Contents

duc2005_docs.tar.gz:
  Test document sets

#Summary Content Units，相当于对句子进行了切分，到时抽取句子的时候就直接从这里抽取
SCU-MarkedCorpus-2005.zip:
  SCU-Marked Source Documents
(courtesy of University of Ottawa. Please see U. Ottawa's DUC 2005
proceedings paper:
http://duc.nist.gov/pubs/2005papers/uottawa.copeck2.pdf)


3. Contact Information

For further information about the contents of this data release,
please contact:

  Hoa Dang, NIST, TAC/DUC organizer                <hoa.dang@nist.gov>
